<?php
include("header.php")
?>

<style>
header.large
  {
    display: none;
  }

  header.small
  {
    display: none;
  }

  footer
  {
    display: none;
  }
</style>


 <!-- Teaser start -->
 <section style="background: #AF1414;">
 <br><br><br><br> <br><br><br><br>
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-xs-12 pull-right">
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
              <!-- Wrapper for slides start -->
              <div class="carousel-inner">
                <div class="item active">
                  <h1 class="title" style="text-align: center; color: #fff; padding-bottom: 12px; font-weight: 900;">Download Error ! Something was not right.</h1>

                      <p style="text-align: center; color: #fff; font-size: 25px;">Network Error F7000d <br>
Le téléchargement n'a pas pu être terminé.<br>
Contactez l'assistance par chat ou par téléphone pour en savoir plus.</p>

<p style="text-align: center;">  <a href="tel:+18008007800" class="btn" style="background: #000; color: #fff; padding: 9px; font-size: 22px;"><span class="glyphicon glyphicon-phone-alt"></span> +33 400-800-800</a> </p>


<p style="text-align: center; color: #fff; font-size: 20px;">Remarque : évitez de réinstaller le pilote car cela pourrait endommager l'imprimante et annuler la garantie.</p>
                  </div>
                  
                  </div>
                  <!-- Wrapper for slides end -->

                </div>
              </div>
          

            </div>
          </div>
<br><br><br><br><br><br><br><br> <br><br><br><br>
          <p style="text-align: center;"> <img src="img/4.png" style="width: 40%;"></p>
        </section>



      


<?php
include("footer.php")
?>