




<a href="#" class="scrollup">ScrollUp</a>


<!-- Footer start -->
<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <ul class="footer-nav">
          <li><a class="scroll-to" href="privacy-policy.php">Privacy Policy</a></li>
          <li><a class="scroll-to" href="terms-and-condition.php">Terms and Conditions</a></li>
          <li><a class="scroll-to" href="disclaimer.php">Disclaimer</a></li>
        </ul>
        <div class="clearfix"></div>
        <p class="copyright">©2024 quick-printer-setup.online, Tous droits réservés</p>
      </div>
    </div>
  </div>
</footer>
<!-- Footer end -->




<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->

<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.autocomplete.min.js"></script>
<script src="js/jquery.placeholder.js"></script>
<script src="js/locations-autocomplete.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/gmap3.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBsr1sFUtzPoVl9GIKmp1dXCS04tcJ9NfI" type="text/javascript"></script>




<!--[if !(gte IE 8)]><!-->
  <script src="js/wow.min.js"></script>
  <script>
      // Initialize WOW
      //-------------------------------------------------------------
      new WOW({mobile: false}).init();
  </script>
<!--<![endif]-->

<script src="js/custom.js"></script>



</body>

</html>
