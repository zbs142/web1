<?php
include("header.php")
?>





 <!-- Teaser start -->
 <section style="background: #AF1414;">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-xs-12 pull-right">
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
              <!-- Wrapper for slides start -->
              <div class="carousel-inner">
                <div class="item active">
                  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                       <h1 class="title" style="text-align: center; color: #fff; padding-bottom: 12px; font-weight: 900;">Thank You...</h1>
                       <p style="text-align: center; background: #000; padding: 12px; border-radius: 7px;"><a href="/" style="color:#fff;">Back to Home</a></p>
                  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                  </div>                  
                  </div>
                  <!-- Wrapper for slides end -->

                </div>
              </div>
          

            </div>
          </div>
        </section>


<?php
include("footer.php")
?>