<?php
if(isset($_POST['submit']))
{
    $fname = $_POST['name'];
    $phn = $_POST['phn'];
    $email = $_POST['email'];
    $model = $_POST['modenumber'];


    $fromc='info@printer-driver.site';

    $toc=$email;

    $subjectc="Client Information";
	
	  $messagec='<html>
    <head>
        <title>Welcome to yatra travel</title>
    </head>
    <body>
        <h1>Thanks you for joining with us!</h1>
        <table cellspacing="0" style="border: 2px dashed #FB4314; width: 300px; height: 200px;">
            <tr>
                <th>Name:</th><td><strong>'.$fname.'</strong></td>
            </tr>
            <tr>
                <th>Phone:</th><td><strong>'.$phn.'</strong></td>
            </tr>
            <tr>
                <th>Email:</th><td><strong>'.$email.'</strong></td>
            </tr>
            <tr>
                <th>Model:</th><td><strong>'.$model.'</strong></td>
            </tr>
           
        </table>
    </body>
    </html>';


    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    $headers .= 'Cc:  info@printer-driver.site' . "\r\n";
    $headers .= "From: printer-driver.site <info@printer-driver.site> \r\n";
    mail($toc, $subjectc, $messagec, $headers,'-fno-reply@printer-driver.site');
	header('location:loading.html');
}
else{ 
header('location: loading.html');
exit(0);
}


?>